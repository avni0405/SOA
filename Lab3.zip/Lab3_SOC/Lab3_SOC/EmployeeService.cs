﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Data.SqlTypes;
namespace Lab3_SOC
{
    
   public class EmployeeService:IEmployeeService
    {
        public Employee GetEmployee(int Id)
        {
            Employee employee = new Employee();
            string cs = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=MyDb;Integrated Security=True;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "Select Id,Name,Gender,DateOfBirth from Employee where Id=@Id";
                SqlParameter pid = new SqlParameter();
                pid.ParameterName = "@Id";
                pid.Value = Id;
                cmd.Parameters.Add(pid);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while(reader.Read())
                {
                    employee.Id = Convert.ToInt32(reader["Id"]);
                    employee.Name = reader["Name"].ToString();
                    employee.Gender = reader["Gender"].ToString();
                    employee.DateOfBirth = Convert.ToDateTime(reader["DateOfBirth"]);
                }
            }

            return employee;
        }
        public void SaveEmployee(Employee emp)
        {
            string cs = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=MyDb;Integrated Security=True;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "INSERT INTO Employee(Id,Name,Gender,DateOfBirth)VALUES (@Id,@Name,@Gender,@DateOfBirth)";
                SqlParameter pid = new SqlParameter
                {
                    ParameterName = "@Id",
                    Value = emp.Id
                };
                cmd.Parameters.Add(pid);
                SqlParameter pname = new SqlParameter
                {
                    ParameterName = "@Name",
                    Value = emp.Name
                };
                cmd.Parameters.Add(pname);
                SqlParameter pg = new SqlParameter
                {
                    ParameterName = "@Gender",
                    Value = emp.Gender
                };
                cmd.Parameters.Add(pg);
                SqlParameter pd = new SqlParameter
                {
                    ParameterName = "@DateOfBirth",
                    Value = emp.DateOfBirth

                };
                cmd.Parameters.Add(pd);
                con.Open();
                cmd.ExecuteNonQuery();
            
            }
        }
    }
}
