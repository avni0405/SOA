﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static System.Net.WebRequestMethods;

namespace Lab3_Client
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
          HTTP.EmployeeServiceClient client = new HTTP.EmployeeServiceClient();
           HTTP.Employee emp = client.GetEmployee(Convert.ToInt32(TextBox1.Text));
            TextBox2.Text = emp.Name;
            TextBox3.Text = emp.Gender;
            TextBox4.Text = emp.DateOfBirth.ToShortDateString();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            HTTP.Employee emp = new HTTP.Employee();
            emp.Id = Convert.ToInt32(TextBox1.Text);
            emp.Name = TextBox2.Text;
            emp.Gender = TextBox3.Text;
            emp.DateOfBirth = Convert.ToDateTime(TextBox4.Text);
            HTTP.EmployeeServiceClient c = new HTTP.EmployeeServiceClient();
            c.SaveEmployee(emp);

        }
    }
}